<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['upload_invalid_filetype'] = 'Upload invalid file type';
$lang['upload_invalid_filesize'] = 'Upload invalid file size';
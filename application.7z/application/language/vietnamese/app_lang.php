<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['label_home'] = 'Trang chủ';
$lang['label_about_us'] = 'Về chúng tôi';
$lang['label_introduce'] = 'Liên hệ';
$lang['label_news'] = 'Tin tức';
$lang['label_event'] = 'Sự kiện';
$lang['label_news_event'] = 'Tin tức và sự kiện';
$lang['label_contact'] = 'Liên hệ';
$lang['label_post'] = 'Bài viết';
$lang['label_new_post'] = 'Bài viết mới';
$lang['label_key_word'] = 'Từ khóa';
$lang['label_read_more'] = 'Đọc thêm';
$lang['label_search'] = 'Tìm kiếm';
$lang['label_register'] = 'Đăng ký';
$lang['label_register_now'] = 'Đăng ký ngay';
$lang['label_name'] = 'Tên';
$lang['label_full_name'] = 'Họ tên';
$lang['label_first_name'] = 'Tên';
$lang['label_last_name'] = 'Họ';
$lang['label_phone'] = 'Điện thoại';
$lang['label_pasword'] = 'Mật khẩu';
$lang['label_repeat_password'] = 'Nhập lại mật khẩu';
$lang['label_address'] = 'Địa chỉ';
$lang['label_age'] = 'Tuổi';
$lang['label_gender'] = 'Giới tính';
$lang['label_male'] = 'Nam';
$lang['label_female'] = 'Nữ';





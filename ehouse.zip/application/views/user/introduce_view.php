 <?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 ?>

<!-- Slider section -->
 <?php require "slider_view.php" ?>
 <!-- End slider section -->
<div class="container"><?php echo $item->description; ?></div>
<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<li class="divider"></li>
<li><a href="<?php echo site_url('admin/groups'); ?>">Groups</a></li>
<li><a href="<?php echo site_url('admin/users'); ?>">Users</a></li>
<?php include "header_view.php"; ?>
<?php defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="text-center" style="color: #286090">POLICY</h3>
            <div class="pd-lr-5"><?php echo $item->description; ?></div>
        </div>
    </div>
</div>
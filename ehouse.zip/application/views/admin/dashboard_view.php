<div class="container" style="margin-top:60px;">
	<h1>Welcome to the Dashboard!</h1>
    <div class="row">
        <div class="col-lg-12">
            <?php
            echo anchor('admin/dashboard/clear_cache','Clear cache','class="btn btn-primary"');
            ?>
        </div>
    </div>
</div>
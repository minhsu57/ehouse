<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['label_home'] = 'Home';
$lang['label_about_us'] = 'About us';
$lang['label_introduce'] = 'Introduce';
$lang['label_news'] = 'News';
$lang['label_event'] = 'Event';
$lang['label_news_event'] = 'News and event';
$lang['label_contact'] = 'Contact';
$lang['label_post'] = 'Post';
$lang['label_new_post'] = 'New Post';
$lang['label_key_word'] = 'Key word';
$lang['label_read_more'] = 'Read more';
$lang['label_register'] = 'Register';
$lang['label_register_now'] = 'Register Now';
$lang['label_name'] = 'Name';
$lang['label_full_name'] = 'Full name';
$lang['label_first_name'] = 'Full name';
$lang['label_last_name'] = 'Full name';
$lang['label_phone'] = 'Phone';
$lang['label_pasword'] = 'Password';
$lang['label_repeat_password'] = 'Repeat password';
$lang['label_address'] = 'Address';
$lang['label_age'] = 'Age';
$lang['label_gender'] = 'Gender';
$lang['label_male'] = 'Male';
$lang['label_female'] = 'Female';


import { AndonWebPage } from './app.po';

describe('andon-web App', () => {
  let page: AndonWebPage;

  beforeEach(() => {
    page = new AndonWebPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});

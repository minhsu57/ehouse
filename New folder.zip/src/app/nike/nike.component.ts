import { Component, OnInit, AfterViewInit } from '@angular/core';
import { RestService } from '../share/rest.service';
import { ListService } from '../share/list.service';
import $ from 'jquery';

@Component({
  selector: 'app-nike',
  templateUrl: './nike.component.html'
})
export class NikeComponent implements OnInit {

  domain = '';
  groupID  = '';
  tonggleEditID  = -1;        // display: none
  tonggleEditAll = false;     // display: none
  modeShowRowAdd = true;      // display: none
  factory = '';
  factoryAdd = '';
  artNo = '';
  astNoCopy = '';
  orderMonth = '';
  listMasterData: any[] = [];
  listFactory: any[] = [];
  objDataSave: any [] = [];
  objCopyDataEdit = {};
  objCopyDataAllEdit: any[] = [];
  colorWayCopy  = '';
  objCopyListAddData: any;
  currentItemID = -1;
  currentSysDate = '';
  flagLoader    = true; // disable display
  flagAddData   = true;

  // button control master
  flagEditAll       = true;
  flagSaveCancelAll = true;

  //permission download file
  flagNullInputMonth   = true;
  flagPermission       = true;
  flagPermissionUpdate = true;
  flagPermissionSpec   = true;

  // pagination
  totalItemSearch: number = 0;
  page: number  = 1;
  itemStart: number = 0;
  itemEnd: number = 10;

  message     = '';
  disableAllModify = false;
  listAddData = {
        "factory": null,
        "brand":"NIKE",
        "buyer": null,
        "dateQuoted": null,
        "artNo":null,
        "artName":null,
        "profit":null,
        "currency":null,
        "upperMaterials":null,
        "packaging":null,
        "midSole":null,
        "outSole":null,
        "sizeUp":null,
        "labor":null,
        "overHead":null,
        "processCost":null,
        "otherAdjustment":null,
        "sampleTooling":null,
        "productionTooling":null,
        "specialSurcharge":null,
        "profitML":null,
        "cbd":null,
        "modifiedBy":null,
        "modifiedTime":null,
        "createBy":null,
        "createTime":null,
        "status":"Y"      
    };

  constructor(private service: RestService, private listService: ListService) {
    this.domain = this.listService.DOMAIN_NAME_233;
    this.objCopyListAddData =  Object.assign({}, this.listAddData);
  }

  ngOnInit() {
    this.getlistFactory();
    this.getLocalDate();
    this.groupID = this.getGID('gid');
  }

  permissionDownload() {
    this.service.get(this.domain + this.listService.PERMISSION_CONVERSE + '?GID=' + this.groupID).subscribe(response => {
      let dataP = response[0].guest.toUpperCase();
      if (dataP == 'FACTORY')  {
        this.flagPermission       = false;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = true;
      }else if (dataP == 'COSTING') {
        this.flagPermission       = false;
        this.flagPermissionUpdate = false;
        this.flagPermissionSpec   = false;
      }else if (dataP == 'AUDIT') {
        this.flagPermission       = false;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = false;
      }else{
        this.flagPermission       = true;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = true;
      }
    });
  }

  downloadCBDLIST(){
    this.exportFile(this.domain + this.listService.NIKE_EXPORT_CBDLIST
     + '?factory=' + this.factory + '&articNo=' + this.artNo + '&orderMonth=' + this.orderMonth , 'export_nike_CBD_list', '', '.xls' );
  }

  downloadFileFactory(factory, artNo, ordermonth=this.orderMonth){
    this.exportFile(this.domain + this.listService.NIKE_EXPORT_FACTORY 
      + '?factory=' + factory + '&articNo=' + artNo + '&orderMonth=' + ordermonth, 'export_factory_nike', '', '.xls' );
  }

  downloadFileTrading(factory, artNo, ordermonth=this.orderMonth){
    this.exportFile(this.domain + this.listService.NIKE_EXPORT_TRADING 
      + '?factory=' + factory + '&articNo=' + artNo + '&orderMonth=' + ordermonth, 'export_nike_trading', '', '.xls' );
  }

  exportFile= function(url, filename, data, fileType) {
            fileType = fileType || '.xls';
            filename = (filename) ? (filename  + fileType) : 'Export.csv';
            let stringHeaders = {};
            this.flagLoader   = false;
            let blobType = {};
            if ( fileType === '.xls' || fileType === '.xlsx' ) {
                blobType = { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
                stringHeaders = {'Content-Type' : 'application/x-www-form-urlencoded'} ;
            }else {
                stringHeaders = {'Content-Type' : 'text/plain'} ;
            }

            this.service.downLoadFile(url, data, stringHeaders ).subscribe(response => {
                this.flagLoader = true;
                var ieEDGE  = navigator.userAgent.match(/Edge/g),
                    ie      = navigator.userAgent.match(/.NET/g), // IE 11+
                    oldIE   = navigator.userAgent.match(/MSIE/g);
                var blob    = new Blob([response._body], blobType); 

                if (ie || oldIE || ieEDGE) {
                    window.navigator.msSaveBlob(blob, filename);
                    this.message  = 'Download file succeed!';
                }else {
                    this.message  = 'Download file succeed!';
                    let link = (<HTMLElement>document.createElement('a'));
                    link.setAttribute('style', 'display: none');
                    let url = window.URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', filename);
                    $('body').append(link);
                    link.click();
                    setTimeout(() => {
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(url);
                    }, 100);
                }
            });
    }

  setCurrentItem(itemID){
    this.currentItemID = itemID;
  }
  
  copyData(option){
      if (this.currentItemID >= 0){
          if(option == 'copy'){
            this.astNoCopy = '';
            document.getElementById('showModalAstNo').click();
          }else{
             if( this.astNoCopy != ''){
                let itemObj   = this.listMasterData[this.currentItemID];
                itemObj.artNo = this.astNoCopy.toUpperCase();
                this.service.put(this.domain + this.listService.NIKE_COPY_ADD,itemObj).subscribe(response =>{
                    if( response.flag){
                      document.getElementById('showModalAstNo').click();
                      this.searchMasterData();
                      this.message     = response.message;
                    }else {
                      document.getElementById('showModalAstNo').click();
                      document.getElementById('showModalMessage').click();
                      this.message     = response.message;
                    }
                })
             }
          }
      }
  }
  
  addNewData(){
        let itemObj   = this.listAddData;
        itemObj.factory           = itemObj.factory   != null ? itemObj.factory.toUpperCase() : null;
        itemObj.artNo             = itemObj.artNo  != null ? itemObj.artNo.toUpperCase() : null;
        itemObj.currency          = itemObj.currency  != null ? itemObj.currency.toUpperCase() : null;
        itemObj.upperMaterials    = itemObj.upperMaterials   != null ? Number(itemObj.upperMaterials) : null;
        itemObj.packaging         = itemObj.packaging   != null ? Number(itemObj.packaging) : null;
        itemObj.midSole           = itemObj.midSole != null ? Number(itemObj.midSole) : null;
        itemObj.outSole           = itemObj.outSole != null ? Number(itemObj.outSole) : null ;
        itemObj.sizeUp            = itemObj.sizeUp != null ? Number(itemObj.sizeUp) : null;
        itemObj.labor             = itemObj.labor != null ? Number(itemObj.labor) : null;
        itemObj.overHead          = itemObj.overHead != null ? Number(itemObj.overHead) : null;
        itemObj.processCost       = itemObj.processCost != null ? Number(itemObj.processCost) : null;
        itemObj.otherAdjustment   = itemObj.otherAdjustment != null ? Number(itemObj.otherAdjustment) : null ;
        itemObj.sampleTooling     = itemObj.sampleTooling != null ? Number(itemObj.sampleTooling) : null;
        itemObj.productionTooling = itemObj.productionTooling != null ? Number(itemObj.productionTooling) : null ;
        itemObj.specialSurcharge  = itemObj.specialSurcharge != null ? Number(itemObj.specialSurcharge) : null;
        this.service.put(this.domain + this.listService.NIKE_COPY_ADD, itemObj).subscribe(response =>{
        if (response.flag) {
            this.tonggleCancelMode();
            this.tonggleMusMode();
            this.tonggleCancelDataAll();
            this.searchMasterData();
            this.message = response.message;
        }else {
            this.message = response.message;
        }
        setTimeout(function(){
          document.getElementById('showModalMessage').click();
        }, 2000)
      });

  }

  saveData(itemID, option) {
     let itemObj   = option == 'saveAll' ? this.listMasterData : this.listMasterData[itemID];
     if( option == 'saveAll'){
       for( let i=0; i< itemObj.length; i++){
        let itemObj_ = itemObj[i];
        itemObj_.factory           = itemObj_.factory          != null ? itemObj_.factory.toUpperCase() : null;
        itemObj_.artNo             = itemObj_.artNo            != null ? itemObj_.artNo.toUpperCase() : null;
        itemObj_.currency          = itemObj_.currency         != null ? itemObj_.currency.toUpperCase() : null;
        itemObj_.upperMaterials    = itemObj_.upperMaterials   != null ? Number(itemObj_.upperMaterials) : null;
        itemObj_.packaging         = itemObj_.packaging        != null ? Number(itemObj_.packaging) : null;
        itemObj_.midSole           = itemObj_.midSole          != null ? Number(itemObj_.midSole) : null;
        itemObj_.outSole           = itemObj_.outSole          != null ? Number(itemObj_.outSole) : null ;
        itemObj_.sizeUp            = itemObj_.sizeUp           != null ? Number(itemObj_.sizeUp) : null;
        itemObj_.labor             = itemObj_.labor            != null ? Number(itemObj_.labor) : null;
        itemObj_.overHead          = itemObj_.overHead         != null ? Number(itemObj_.overHead) : null;
        itemObj_.processCost       = itemObj_.processCost      != null ? Number(itemObj_.processCost) : null;
        itemObj_.otherAdjustment   = itemObj_.otherAdjustment  != null ? Number(itemObj_.otherAdjustment) : null ;
        itemObj_.sampleTooling     = itemObj_.sampleTooling    != null ? Number(itemObj_.sampleTooling) : null;
        itemObj_.productionTooling = itemObj_.productionTooling!= null ? Number(itemObj_.productionTooling) : null ;
        itemObj_.specialSurcharge  = itemObj_.specialSurcharge != null ? Number(itemObj_.specialSurcharge) : null;
        this.objDataSave.push(itemObj_);
       }
     }else{
        itemObj.factory           = itemObj.factory           != null ? itemObj.factory.toUpperCase() : null;
        itemObj.artNo             = itemObj.artNo             != null ? itemObj.artNo.toUpperCase() : null;
        itemObj.currency          = itemObj.currency          != null ? itemObj.currency.toUpperCase() : null;
        itemObj.upperMaterials    = itemObj.upperMaterials    != null ? Number(itemObj.upperMaterials) : null;
        itemObj.packaging         = itemObj.packaging         != null ? Number(itemObj.packaging) : null;
        itemObj.midSole           = itemObj.midSole           != null ? Number(itemObj.midSole) : null;
        itemObj.outSole           = itemObj.outSole           != null ? Number(itemObj.outSole) : null ;
        itemObj.sizeUp            = itemObj.sizeUp            != null ? Number(itemObj.sizeUp) : null;
        itemObj.labor             = itemObj.labor             != null ? Number(itemObj.labor) : null;
        itemObj.overHead          = itemObj.overHead          != null ? Number(itemObj.overHead) : null;
        itemObj.processCost       = itemObj.processCost       != null ? Number(itemObj.processCost) : null;
        itemObj.otherAdjustment   = itemObj.otherAdjustment   != null ? Number(itemObj.otherAdjustment) : null ;
        itemObj.sampleTooling     = itemObj.sampleTooling     != null ? Number(itemObj.sampleTooling) : null;
        itemObj.productionTooling = itemObj.productionTooling != null ? Number(itemObj.productionTooling) : null ;
        itemObj.specialSurcharge  = itemObj.specialSurcharge  != null ? Number(itemObj.specialSurcharge) : null;
        this.objDataSave.push(itemObj);
     }
     
     this.service.put(this.domain + this.listService.NIKE_UPDATE, this.objDataSave).subscribe(response =>{
        if (response.flag) {
            this.tonggleCancelMode();
            this.tonggleMusMode();
            this.tonggleCancelDataAll();
            this.searchMasterData();
            this.message     = response.message;
        }else {
            this.message     = response.message;
        }
        this.objDataSave.length = 0;
        setTimeout(function(){
          document.getElementById('showModalMessage').click();
        }, 2000)
      });
  }

  searchMasterData(option="search",itemStart = this.itemStart, itemEnd = this.itemEnd) {
      this.flagLoader     = false;
      this.tonggleEditID  = -1; // false disabled
      this.tonggleEditAll = false; // false disabled
      let item = {
          "factory": this.factory,
          "artNo": this.artNo.toUpperCase(),
          "documentDate" : this.orderMonth
      };
      this.service.put(this.domain + this.listService.NIKE_SEARCH + '?start='+ itemStart + '&row=' + itemEnd ,item).subscribe(response => {
            this.flagLoader  = true;
            this.listMasterData.length = 0;
            if (response.length > 0) {
              this.flagEditAll    = false;
              this.listMasterData = response;
              this.currentItemID  = -1;
              if( option == 'search'){
                this.page = 1;
              }
              if( this.orderMonth != '') {
                this.flagNullInputMonth = false;
              }else{
                this.flagNullInputMonth = true;
              }
            }
      });
      this.countTotalItemSearch();
  }

  countTotalItemSearch() {
    let item = {
          "factory": this.factory,
          "artNo": this.artNo.toUpperCase(),
          "documentDate" : this.orderMonth
      };
    this.service.put(this.domain + this.listService.NIKE_SEARCH_TOTAL, item).subscribe(response =>{
          this.totalItemSearch = response;
    })
  }

  pageChanged(event) {
    this.page     = event;
    let itemStart = (event * this.itemEnd) - this.itemEnd ;
    this.searchMasterData('pageChange',itemStart);
  }

  deleteMasterData(factory, artNo) {
    let item = {
      "factory": factory,
	    "artNo"  : artNo
    };
    this.service.put(this.domain + this.listService.NIKE_DELETE, item).subscribe( response => {
      if ( response.flag) {
        this.searchMasterData();
        this.message     = response.message;
      }else {
        this.message     = response.message;
      }
      setTimeout(function(){
        document.getElementById('showModalMessage').click();
      }, 2000);
    });
  }
    
  sumProfit(itemID, option) {
    let itemObj = option == 'add' ? this.listAddData : this.listMasterData[itemID];
    let profit          = itemObj.profit != null ? itemObj.profit.slice(0, -1) : 0;
    let upperMaterials  = Number(itemObj.upperMaterials) + 0;
    let packaging       = Number(itemObj.packaging) + 0;
    let midSole         = Number(itemObj.midSole) + 0;
    let outSole         = Number(itemObj.outSole) + 0;
    let sizeUp          = Number(itemObj.sizeUp) + 0;
    let labor           = Number(itemObj.labor) + 0;
    let overHead        = Number(itemObj.overHead) + 0;
    let processCost     = Number(itemObj.processCost) + 0;
    let otherAdjustment = Number(itemObj.otherAdjustment) + 0;
    let sampleTooling   = Number(itemObj.sampleTooling) + 0;
    let productionTooling= Number(itemObj.productionTooling) + 0;
    let specialSurcharge = Number(itemObj.specialSurcharge) + 0;

    let columnSum      = upperMaterials + packaging + midSole + outSole + sizeUp + labor 
                        + overHead + processCost + otherAdjustment + sampleTooling + productionTooling + specialSurcharge;
    let totalSumProfit = (columnSum * Number(profit)/ 100).toFixed(2);
    let totalCBD       = (Number(columnSum) + Number(totalSumProfit)).toFixed(2);
    itemObj.profitML   = Number(totalSumProfit);
    itemObj.cbd        = Number(totalCBD);

    // check for control button save true or false
    this.flagAddData = true; // disabled button save
    if(option == 'add'){
      if( itemObj.factory != null  && itemObj.artNo != null 
        && itemObj.dateQuoted != null && itemObj.profit != null){
        this.flagAddData = false;
      }
    }else{
      for ( let i = 0; i < this.listMasterData.length; i++){
          if ( this.listMasterData[i].dateQuoted != null && this.listMasterData[i].profit != null ) {
            this.flagAddData = false;
          }else {
            this.flagAddData = true;
            break;
          }
      }
    }
  }

  validateNumber(event){
      var charCode = (event.which) ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
          return false;
      }
      else {
          var parts = event.srcElement.value.split('.');
          if (parts.length > 1 && charCode == 46)
            {
              return false;
            }
          return true;
      }
  }

  validateProfit(event,itemID, option) {
      this.flagAddData = true; // disabled button save
      let itemObj = option == 'add' ? this.listAddData : this.listMasterData[itemID];
      let profit  = event.target.value;
      let pattern = /^([0-9]{1})+\%$/;
      if(pattern.test(profit)) {
        this.sumProfit(itemID,option);
      }else{
        itemObj.profit = null;
      }
  }

  checkFormatDate(event,itemID,option, name){
    this.flagAddData = true; // disabled button save
    let itemObj   = option == 'add' ? this.listAddData : this.listMasterData[itemID];
    let startDate = event.target.value;
    let pattern   = /^([0-9]{4})\/([0-9]{2})\/([0-9]{2})$/;
    if (pattern.test(startDate)) {
        this.sumProfit(itemID,option);
    }else {
        if( name == 'dateQuoted'){
          itemObj.dateQuoted = null;
        }
    }
  }

  checkFormatDataMaster(event, name) {
      let startDate = event.target.value;
      let pattern   = /^([0-9]{4})\/([0-9]{2})$/;
      if (pattern.test(startDate)) {
          return;
      }else {
           if ( name == 'orderMonth') {
            this.orderMonth = '';
          }
      }
  }

  getLocalDate(){
    this.service.get(this.domain + this.listService.CURRENTDATE_CONVERSE)
                .subscribe(response => {
                  this.currentSysDate  = response[0];
                });
  }

  selectFactory(item,option) {
    if( option == 'search') {
      this.factory = item;
    }else {
      this.listAddData.factory = item;
      this.sumProfit('-1','add');
    }
  }

  getlistFactory() {
    this.service.get(this.domain + this.listService.GET_FACTORY).subscribe(response =>{
      this.listFactory = response;
    });
  }

  tonggleEditAllData() {
    this.flagEditAll       = true;
    this.flagSaveCancelAll = false;
    this.tonggleCancelMode('disabledEditAll');
    this.tonggleEditAll = true;
    this.disableAllModify = true;
    for ( let i = 0; i < this.listMasterData.length; i++) {
      this.objCopyDataAllEdit.push(Object.assign({}, this.listMasterData[i]));
      this.listMasterData[i].modifiedTime = this.currentSysDate;
      this.listMasterData[i].modifiedBy   = this.groupID;
    }
  }

  tonggleCancelDataAll() {
    this.flagEditAll       = false;
    this.flagSaveCancelAll = true;
    this.tonggleEditAll    = false;
    this.disableAllModify  = false;
    for ( let i = 0; i < this.objCopyDataAllEdit.length; i++) {
      this.listMasterData[i] = this.objCopyDataAllEdit[i];
    }
    this.objCopyDataAllEdit.length = 0;
  }

  tonggleEditMode(tonggleEditID) {
    this.flagEditAll     = true;
    this.flagAddData     = false; // not disabled button save
    this.tonggleEditID   = tonggleEditID;
    this.objCopyDataEdit = Object.assign({}, this.listMasterData[tonggleEditID]);
    this.listMasterData[tonggleEditID].modifiedTime = this.currentSysDate;
    this.listMasterData[tonggleEditID].modifiedBy   = this.groupID;
  }

  tonggleCancelMode(option='') {
    this.listMasterData[this.tonggleEditID] = this.objCopyDataEdit; 
    this.tonggleEditID = -1;
     if(option == 'disabledEditAll'){
        this.flagEditAll = true;
     }else{
        this.flagEditAll = false;
     }
  }

  // add new 
  tongglePlusMode() {
    this.modeShowRowAdd = false;
    this.listAddData.dateQuoted = this.currentSysDate;
    this.listAddData.modifiedBy = this.groupID;
    this.listAddData.modifiedTime = this.currentSysDate;
  }

  // cancel add new
  tonggleMusMode() {
    this.modeShowRowAdd = true;
    this.listAddData    = this.objCopyListAddData;
  }

  isShowSelectMode(tonggleID) {
    return  tonggleID === this.tonggleEditID;
  }

  getGID(name) {
      name      = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
      var regexS= "[\\?&]"+name+"=([^&#]*)";
      var regex = new RegExp( regexS );
      var results = regex.exec( window.location.href );
      if( results == null ) {
        return '';
      }else {
        return results[1];
      }
   }

   ngAfterViewInit(){
      this.permissionDownload();
  }

}

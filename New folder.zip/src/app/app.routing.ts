
import { RouterModule, Routes } from '@angular/router';
import { TradingCompanyComponent } from './trading-company/trading-company.component';
import { NikeComponent } from './nike/nike.component';
import { ConverseComponent } from './converse/converse.component';
import { ConverseFactoryComponent } from './converse-factory/converse-factory.component';
import { NikeFactoryComponent } from './nike-factory/nike-factory.component';

const routes: Routes = [
  { path: '', component: TradingCompanyComponent},
  { path: 'trading-company', component: TradingCompanyComponent},
  { path: 'nike', component: NikeComponent },
  { path: 'nike-factory', component: NikeFactoryComponent },
  { path: 'converse', component: ConverseComponent },
  { path: 'converse-factory', component: ConverseFactoryComponent }
];

export const appRouting = RouterModule.forRoot(routes);

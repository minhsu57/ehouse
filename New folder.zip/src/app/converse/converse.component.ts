import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { RestService } from '../share/rest.service';
import { ListService } from '../share/list.service';
import $ from 'jquery';

@Component({
  selector: 'app-converse',
  templateUrl: './converse.component.html'
})
export class ConverseComponent implements OnInit {

  domain = '';
  groupID  = '';
  tonggleEditID  = -1;        // display: none
  tonggleEditAll = false;     // display: none
  modeShowRowAdd = true;      // display: none
  factory = '';
  factoryAdd = '';
  colorway = '';
  season = '';
  seasonAdd = '';
  startDate = '';
  endDate  = '';
  listMasterData: any[] = [];
  listFactory: any[] = [];
  listSeason: any[] = [];
  objDataSave: any [] = [];
  objCopyDataEdit = {};
  objCopyDataAllEdit: any[] = [];
  colorWayCopy  = '';
  objCopyListAddData: any;
  currentItemID  = -1;
  currentSysDate = '';
  flagMessage = false;
  flagLoader  = true; // disable display
  flagAddData = true;

  // pagination
  totalItemSearch: number = 0;
  page: number  = 1;
  itemStart: number = 0;
  itemEnd: number = 10;


  // button control master
  flagEditAll       = true;
  flagSaveCancelAll = true;

  //permission download file
  flagNullInputMonth   = true;
  flagPermission       = true;
  flagPermissionUpdate = true;
  flagPermissionSpec   = true; // this is different Audit and costing download CBD list

  message = '';
  disableAllModify = false;
  listAddData = {
        "factory": null,
        "colorWay": null,
        "profit": null,
        "brand": 'Converse',
        "buyer": null,
        "season": null,
        "cbdDate": null,
        "artName": null,
        "currency": null,
        "uppersA": null,
        "liningB":null,
        "reinForceMentC": null,
        "componentsD": null,
        "logoE": null ,
        "bottomUnitF": null,
        "threadG": null,
        "packingH": null,
        "glueI":null,
        "laborCost": null,
        "overHeadCost": null,        
        "specicalSurcharge": null,
        "cbd":null,
        "profitMlab": null,
        "modifiedBy": null,
        "modifiedTime":null,
        "startDate" :null,
        "endDate" : null,
        "material": null       
    };

  constructor(private service: RestService, private listService: ListService) {
    this.domain = this.listService.DOMAIN_NAME_233;
    this.objCopyListAddData =  Object.assign({}, this.listAddData);
  }

  ngOnInit() {
    this.getlistFactory();
    this.getlistSeason();
    this.getLocalDate();
    this.groupID = this.getGID('gid');
  }

  permissionDownload() {
    this.service.get(this.domain + this.listService.PERMISSION_CONVERSE + '?GID=' + this.groupID).subscribe(response => {
      let dataP = response[0].guest.toUpperCase();
      if (dataP == 'FACTORY')  {
        this.flagPermission       = false;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = true;
      }else if (dataP == 'COSTING') {
        this.flagPermission       = false;
        this.flagPermissionUpdate = false;
        this.flagPermissionSpec   = false;
      }else if (dataP == 'AUDIT') {
        this.flagPermission       = false;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = false;
      }else{
        this.flagPermission       = true;
        this.flagPermissionUpdate = true;
        this.flagPermissionSpec   = true;
      }
    });
  }

  downloadCBDLIST(){
    this.exportFile(this.domain + this.listService.EXPORT_CBDLIST, 'export_converse_CBD_list', '', '.xls' );
  }

  downloadFileFactory(factory, season, colorWay){
    this.exportFile(this.domain + this.listService.EXPORT_FACTORY 
      + '?factory=' + factory + '&season=' + season + '&colorWay=' + colorWay, 'export_converse_factory', '', '.xls' );
  }

  downloadFileTrading(factory, season, colorWay){
    this.exportFile(this.domain + this.listService.EXPORT_TRADING 
      + '?factory=' + factory + '&season=' + season + '&colorWay=' + colorWay, 'export_converse_trading', '', '.xls' );
  }

  exportFile= function(url, filename, data, fileType) {
            fileType = fileType || '.xls';
            filename = (filename) ? (filename  + fileType) : 'Export.csv';
            let stringHeaders = {};
            this.flagLoader   = false;
            let blobType = {};
            if ( fileType === '.xls') {
                blobType = { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
                stringHeaders = {'Content-Type' : 'application/x-www-form-urlencoded'} ;
            }else {
                stringHeaders = {'Content-Type' : 'text/plain'} ;
            }

            this.service.downLoadFile(url, data, stringHeaders ).subscribe(response => {
                this.flagLoader = true;
                var ieEDGE  = navigator.userAgent.match(/Edge/g),
                    ie      = navigator.userAgent.match(/.NET/g), // IE 11+
                    oldIE   = navigator.userAgent.match(/MSIE/g);
                var blob    = new Blob([response._body], blobType); 

                if (ie || oldIE || ieEDGE) {
                    window.navigator.msSaveBlob(blob, filename);
                    this.message  = 'Download file succeed!';
                }else {
                    this.message  = 'Download file succeed!';
                    let link = (<HTMLElement>document.createElement('a'));
                    link.setAttribute('style', 'display: none');
                    let url = window.URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', filename);
                    $('body').append(link);
                    link.click();
                    setTimeout(() => {
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(url);
                    }, 100);
                }
            });
    }

  setCurrentItem(itemID){
    this.currentItemID = itemID;
  }
  
  copyData(option) {
      if (this.currentItemID >= 0) {
          if(option == 'copy') {
            this.colorWayCopy = '';
            document.getElementById('showModal').click();
          }else {
             if( this.colorWayCopy != '') {
                let itemObj = this.listMasterData[this.currentItemID];
                itemObj.colorWay = this.colorWayCopy.toUpperCase();
                this.service.put(this.domain + this.listService.COPY_CONVERSE + '?GID='+ this.groupID,itemObj).subscribe(response =>{
                    if( response.flag){
                      document.getElementById('showModal').click();
                      this.searchMasterData();
                      this.message     = "Copy succeed!";
                    }else{
                      document.getElementById('showModalAstNo').click();
                      document.getElementById('showModalMessage').click();
                      this.message     = "Copy failed!";
                    }
                })
             }
          }
      }
  }
  
  saveData(itemID, option) {
     let itemObj   = option == 'add' ? this.listAddData : (option == 'saveAll') ? this.listMasterData : this.listMasterData[itemID];
     if( option == 'saveAll') {
       for( let i=0; i< itemObj.length; i++){
        let itemObj_ = itemObj[i];
        itemObj_.factory = itemObj_.factory   != null ? itemObj_.factory.toUpperCase() : null;
        itemObj_.season  = itemObj_.season    != null ? itemObj_.season.toUpperCase() : null;
        itemObj_.colorWay= itemObj_.colorWay  != null ? itemObj_.colorWay.toUpperCase() : null;
        itemObj_.material= itemObj_.material  != null ? itemObj_.material.toUpperCase() : null;
        itemObj_.currency= itemObj_.currency  != null ? itemObj_.currency.toUpperCase() : null;
        itemObj_.uppersA = itemObj_.uppersA   != null ? Number(itemObj_.uppersA) : null;
        itemObj_.liningB = itemObj_.liningB   != null ? Number(itemObj_.liningB) : null;
        itemObj_.reinForceMentC = itemObj_.reinForceMentC != null ? Number(itemObj_.reinForceMentC) : null;
        itemObj_.componentsD    = itemObj_.componentsD != null ? Number(itemObj_.componentsD) : null ;
        itemObj_.logoE          = itemObj_.logoE != null ? Number(itemObj_.logoE) : null;
        itemObj_.bottomUnitF    = itemObj_.bottomUnitF != null ? Number(itemObj_.bottomUnitF) : null;
        itemObj_.threadG        = itemObj_.threadG != null ? Number(itemObj_.threadG) : null;
        itemObj_.packingH       = itemObj_.packingH != null ? Number(itemObj_.packingH) : null;
        itemObj_.glueI          = itemObj_.glueI != null ? Number(itemObj_.glueI) : null ;
        itemObj_.laborCost      = itemObj_.laborCost != null ? Number(itemObj_.laborCost) : null;
        itemObj_.overHeadCost   = itemObj_.overHeadCost != null ? Number(itemObj_.overHeadCost) : null ;
        itemObj_.specicalSurcharge = itemObj_.specicalSurcharge != null ? Number(itemObj_.specicalSurcharge) : null;
        this.objDataSave.push(itemObj_);
       }
     }else {
        itemObj.factory = itemObj.factory   != null ? itemObj.factory.toUpperCase() : null;
        itemObj.season  = itemObj.season    != null ? itemObj.season.toUpperCase() : null;
        itemObj.colorWay= itemObj.colorWay  != null ? itemObj.colorWay.toUpperCase() : null;
        itemObj.material= itemObj.material  != null ? itemObj.material.toUpperCase() : null;
        itemObj.currency= itemObj.currency  != null ? itemObj.currency.toUpperCase() : null;
        itemObj.uppersA = itemObj.uppersA   != null ? Number(itemObj.uppersA) : null;
        itemObj.liningB = itemObj.liningB   != null ? Number(itemObj.liningB) : null;
        itemObj.reinForceMentC = itemObj.reinForceMentC != null ? Number(itemObj.reinForceMentC) : null;
        itemObj.componentsD = itemObj.componentsD != null ? Number(itemObj.componentsD) : null ;
        itemObj.logoE = itemObj.logoE != null ? Number(itemObj.logoE) : null;
        itemObj.bottomUnitF = itemObj.bottomUnitF != null ? Number(itemObj.bottomUnitF) : null;
        itemObj.threadG = itemObj.threadG != null ? Number(itemObj.threadG) : null;
        itemObj.packingH = itemObj.packingH != null ? Number(itemObj.packingH) : null;
        itemObj.glueI = itemObj.glueI != null ? Number(itemObj.glueI) : null ;
        itemObj.laborCost = itemObj.laborCost != null ? Number(itemObj.laborCost) : null;
        itemObj.overHeadCost = itemObj.overHeadCost != null ? Number(itemObj.overHeadCost) : null ;
        itemObj.specicalSurcharge = itemObj.specicalSurcharge != null ? Number(itemObj.specicalSurcharge) : null;
        this.objDataSave.push(itemObj);
     }
     this.service.put(this.domain + this.listService.SAVE_CONVERSE + '?GID=' + this.groupID, this.objDataSave).subscribe(response =>{
        if (response.flag) {
            this.tonggleCancelMode();
            this.tonggleMusMode();
            this.tonggleCancelDataAll();
            this.searchMasterData();
            this.objDataSave.length = 0;
            this.message     = 'Succeed !';
        }else{
            this.objDataSave.length = 0;
            this.message     = 'Failed !';
        }
        setTimeout(function(){
          document.getElementById('showModalMessage').click();
        }, 2000)
      });
  }

  searchMasterData(option="search",itemStart = this.itemStart, itemEnd = this.itemEnd) {
      this.flagLoader     = false;
      this.tonggleEditID  = -1; // false disabled
      this.tonggleEditAll = false; // false disabled
      this.service.get(this.domain + this.listService.SEARCH_CONVERSE 
        + '?fact=' +  this.factory + '&colorWay=' + this.colorway.toUpperCase() + '&season=' + this.season 
        + '&date1=' + this.startDate + '&date2=' + this.endDate+ '&start=' + itemStart + '&row=' + itemEnd).subscribe(response => {
            this.flagLoader  = true;
            this.listMasterData.length = 0;
            if (response.length > 0) {
              this.listMasterData = response;
              this.flagEditAll = false;
              this.currentItemID = -1;
              if( option == 'search'){
                this.page = 1;
              }
              if( this.startDate != '' && this.endDate != ''){
                this.flagNullInputMonth = false;
              }else{
                this.flagNullInputMonth = true;
              }
            }
      })
      this.countTotalItemSearch();
  }

  countTotalItemSearch() {
    this.service.get(this.domain + this.listService.SEARCH_CONVERSE_TOTAL
        + '?factory=' +  this.factory + '&colorWay=' + this.colorway.toUpperCase() + '&season=' + this.season 
        + '&date1=' + this.startDate + '&date2=' + this.endDate).subscribe(response =>{
          this.totalItemSearch = response;
        })
  }
      
  pageChanged(event) {
    this.page     = event;
    let itemStart = (event * this.itemEnd) - this.itemEnd ;
    this.searchMasterData('pageChange',itemStart);
  }

  deleteMasterData(factory, season, colorWay){
    this.service.delete(this.domain + this.listService.DELETE_CONVERSE + '?factory='+ factory + '&season=' + season + '&colorWay=' + colorWay,'')
    .subscribe( response => {
      if( response.flag) {
        this.searchMasterData();
        this.message = 'Delete Succeed !';
      }else{
        this.message     = response.message;
      }
      setTimeout(function(){
        document.getElementById('showModalMessage').click();
      }, 2000);
    });
  }
    
  sumProfit(itemID, option) {
    let itemObj = option == 'add' ? this.listAddData : this.listMasterData[itemID];
    let profit = itemObj.profit != null ? itemObj.profit.slice(0, -1) : 0;
    let uppersA = Number(itemObj.uppersA) + 0;
    let liningB = Number(itemObj.liningB) + 0;
    let reinForceMentC = Number(itemObj.reinForceMentC) + 0;
    let componentsD = Number(itemObj.componentsD) + 0;
    let logoE = Number(itemObj.logoE) + 0;
    let bottomUnitF = Number(itemObj.bottomUnitF) + 0;
    let threadG = Number(itemObj.threadG) + 0;
    let packingH = Number(itemObj.packingH) + 0;
    let glueI = Number(itemObj.glueI) + 0;
    let laborCost = Number(itemObj.laborCost) + 0;
    let overHeadCost = Number(itemObj.overHeadCost) + 0;
    let specicalSurcharge = Number(itemObj.specicalSurcharge) + 0;

    let columnSum      = uppersA + liningB + reinForceMentC + componentsD + logoE + bottomUnitF + threadG + packingH + glueI + laborCost + overHeadCost + specicalSurcharge;
    let totalSumProfit = (columnSum * Number(profit)/ 100).toFixed(2);
    let totalCBD       = (Number(columnSum) + Number(totalSumProfit)).toFixed(2);
    itemObj.profitMlab = Number(totalSumProfit);
    itemObj.cbd        = Number(totalCBD);

    // check for control button save true or false
    this.flagAddData = true; // disabled button save
    if(option == 'add'){
      if( itemObj.factory != null && itemObj.season != null && itemObj.colorWay != null 
        && itemObj.cbdDate != null && itemObj.profit != null && itemObj.startDate != null && itemObj.endDate != null ){
        this.flagAddData = false;
      }
    }else{
      for ( let i = 0; i < this.listMasterData.length; i++){
          if( this.listMasterData[i].cbdDate != null && this.listMasterData[i].profit != null 
             && this.listMasterData[i].startDate != null  && this.listMasterData[i].endDate != null ){
            this.flagAddData = false;
          }else{
            this.flagAddData = true;
            break;
          }
      }
    }


  }

  validateNumber(event){
      var charCode = (event.which) ? event.which : event.keyCode;
      if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
          return false;
      }
      else {
          var parts = event.srcElement.value.split('.');
          if (parts.length > 1 && charCode == 46)
            {
              return false;
            }
          return true;
      }
  }

  validateProfit(event,itemID, option) {
      this.flagAddData = true; // disabled button save
      let itemObj = option == 'add' ? this.listAddData : this.listMasterData[itemID];
      let profit  = event.target.value;
      let pattern = /^([0-9]{1})+\%$/;
      if(pattern.test(profit)) {
        this.sumProfit(itemID,option);
      }else{
        itemObj.profit = null;
      }
  }

  checkFormatDate(event,itemID,option, name){
    this.flagAddData = true; // disabled button save
    let itemObj   = option == 'add' ? this.listAddData : this.listMasterData[itemID];
    let startDate = event.target.value;
    let pattern   = /^([0-9]{4})\/([0-9]{2})\/([0-9]{2})$/;
    if (pattern.test(startDate)) {
        this.sumProfit(itemID,option);
    }else {
        if( name == 'cbdDate'){
          itemObj.cbdDate = null;
        }else if ( name == 'startDate' ) {
          itemObj.startDate = null;
        }else if ( name == 'endDate' ) {
          itemObj.endDate = null;
        }
    }
  }

  checkFormatDataMaster(event, name) {
      let startDate = event.target.value;
      let pattern   = /^([0-9]{4})\/([0-9]{2})\/([0-9]{2})$/;
      if (pattern.test(startDate)) {
          return;
      }else {
           if ( name == 'startDateM') {
            this.startDate = '';
          }else if (name == 'endDateM') {
            this.endDate  = '';
          }
      }
  }

  getLocalDate(){
    // let dates   = new Date();
    // let years  = dates.getFullYear();
    // let months = (dates.getMonth() + 1) < 10 ? '0' + (dates.getMonth() + 1) : dates.getMonth() + 1 ;
    // let date   = dates.getDate() < 10 ? '0' + dates.getDate() : dates.getDate() ;
    // return years + '/' + months + '/' + date;
     this.service.get(this.domain + this.listService.CURRENTDATE_CONVERSE)
                .subscribe(response => {
                  this.currentSysDate  = response[0];
                });
  }

  selectFactory(item,option) {
    if( option == 'search') {
      this.factory = item;
    }else {
      this.listAddData.factory = item;
      this.sumProfit('-1','add');
    }
  }

  getlistFactory()  {
    this.service.get(this.domain + this.listService.GET_FACTORY).subscribe(response =>{
      this.listFactory = response;
    });
  }

  selectSeason(item,option) {
    if( option == 'search') {
      this.season = item;
    }else {
      this.listAddData.season = item;
      this.sumProfit('-1','add');
    }
  }

  getlistSeason()  {
    this.service.get(this.domain + this.listService.GET_SEASON).subscribe(response => {
      this.listSeason = response;
    });
  }

  tonggleEditAllData() {
    this.flagEditAll = true;
    this.flagSaveCancelAll = false;
    this.tonggleCancelMode('disabledEditAll');
    this.tonggleEditAll = true;
    this.disableAllModify = true;
    for ( let i = 0; i < this.listMasterData.length; i++) {
      this.objCopyDataAllEdit.push(Object.assign({}, this.listMasterData[i]));
      this.listMasterData[i].modifiedTime = this.currentSysDate;
      this.listMasterData[i].modifiedBy   = this.groupID;
    }
  }

  tonggleCancelDataAll() {
    this.flagEditAll        = false;
    this.flagSaveCancelAll  = true;
    this.tonggleEditAll     = false;
    this.disableAllModify   = false;
    for ( let i = 0; i < this.objCopyDataAllEdit.length; i++) {
      this.listMasterData[i] = this.objCopyDataAllEdit[i];
    }
    this.objCopyDataAllEdit.length = 0;
  }

  tonggleEditMode(tonggleEditID) {
    this.flagEditAll     = true;
    this.flagAddData     = false; // not disabled button save
    this.tonggleEditID   = tonggleEditID;
    this.objCopyDataEdit = Object.assign({}, this.listMasterData[tonggleEditID]);
    this.listMasterData[tonggleEditID].modifiedTime = this.currentSysDate;
    this.listMasterData[tonggleEditID].modifiedBy   = this.groupID;
  }

  tonggleCancelMode(option='') {
    this.listMasterData[this.tonggleEditID] = this.objCopyDataEdit; 
    this.tonggleEditID = -1;
    if(option == 'disabledEditAll'){
        this.flagEditAll = true;
     }else{
        this.flagEditAll = false;
     }
  }

  tongglePlusMode() {
    this.modeShowRowAdd = false;
    this.listAddData.cbdDate      = this.currentSysDate;
    this.listAddData.modifiedBy   = this.groupID;
    this.listAddData.modifiedTime = this.currentSysDate;
    this.listAddData.startDate    = this.currentSysDate;
    this.listAddData.endDate      = this.currentSysDate;
  }

  tonggleMusMode() {
    this.modeShowRowAdd = true;
    this.listAddData    = this.objCopyListAddData;
  }

  isShowSelectMode(tonggleID) {
    return  tonggleID === this.tonggleEditID;
  }

  getGID(name) {
      name        = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
      var regexS  = "[\\?&]"+name+"=([^&#]*)";
      var regex   = new RegExp( regexS );
      var results = regex.exec( window.location.href );
      if( results == null ) {
        return '';
      }else {
        return results[1];
      }
   }

  ngAfterViewInit(){
      this.permissionDownload();
  }

}

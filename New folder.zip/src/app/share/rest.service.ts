import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class RestService {

  private headers    = new Headers({'Content-Type' : 'application/json; charset=UTF-8'});

  constructor(private http: Http ) { }

	// tslint:disable-next-line:indent
	get(url: string) {
    	return this.http.get(url).map(response => response.json());
	// tslint:disable-next-line:indent
	}

	// tslint:disable-next-line:indent
	post(url: string, items: any) {
		return this.http.post(url, items, {headers: this.headers} ).map(response => response.json());
	// tslint:disable-next-line:indent
	}

	// tslint:disable-next-line:indent
	put(url: string, items: any) {
		return this.http.put(url, items, {headers: this.headers}).map(response => response.json());
	// tslint:disable-next-line:indent
	}

	// tslint:disable-next-line:indent
	delete(url: string, items: any) {
		return this.http.delete(url, new RequestOptions({
                headers: this.headers,
                body: items
            })).map(response => response.json());
	}

	// tslint:disable-next-line:indent
	public uploadFile(url: string, formData: any) {
        return this.http.post(url, formData)
        .catch(this.errorHandler);
	}
	
	// tslint:disable-next-line:indent 
	public downLoadFile(url: string, formData: any, objContentType: any) {
		//download file csv, xls
		const headers = new Headers(objContentType);
        const option  = new RequestOptions({ headers: headers, responseType: ResponseContentType.ArrayBuffer});
		return this.http.post(url, formData, option );
	}

    private errorHandler(error: Response) {
        console.log('Error Occured: ' + error);
        return Observable.throw(error || 'Some Error on Server Occured');
    }

}

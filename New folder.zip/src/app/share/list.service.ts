
export class ListService  {

  public  DOMAIN_NAME 	      = 'http://172.16.3.126:8080/';
  public  DOMAIN_NAME_233     = 'http://172.21.6.233:8080/';

  // ============== Trading company ==============
  public  GET_FACTORY	        = 'PCNTrading/common/getFactory';
  public  GET_BRAND		        = 'PCNTrading/common/getBrand';
  public  GET_FILETYPE	      = 'PCNTrading/common/getFileType?brand='; // $brand
  public  POST_IMPORT_PEGASUS = 'PCNTrading/CSV/importPegasusOBS?brand=';
  public  POST_IMPORT_MERCURY = 'PCNTrading/importDFD?factory=';
  public  POST_IMPORT_EEM     = 'PCNTrading/importEMM?factory=';
  public  POST_EXPORT_PEGASUS = 'PCNTrading/CSV/exportPegasusOBS?brand=';
  public  POST_EXPORT_MERCURY = 'PCNTrading/exportDFD?factory=';
  public  POST_EXPORT_EEM     = 'PCNTrading/exportEMM?factory=';

  // ============== Converse ==============
  public SEARCH_CONVERSE      = 'PCNTrading/seacrhCBDConverse';
  public SEARCH_CONVERSE_TOTAL= 'PCNTrading/countSearchCBDConverse';
  public SAVE_CONVERSE        = 'PCNTrading/SaveCBDConverse';
  public DELETE_CONVERSE      = 'PCNTrading/DeleteCBDConverse';
  public COPY_CONVERSE        = 'PCNTrading/CopyCBDConverse';
  public EXPORT_TRADING       = 'PCNTrading/exportCBDConverseTrading';
  public EXPORT_FACTORY       = 'PCNTrading/exportCBDConverseFactory';
  public EXPORT_CBDLIST       = 'PCNTrading/exportCBDList';
  public EXPRORT_PRICELIST    = 'PCNTrading/exportPriceConfirmedList';
  public GET_SEASON           = 'PCNTrading/common/getSeason';
  public PERMISSION_CONVERSE  = 'PCNTrading/common/getPermision';
  public CURRENTDATE_CONVERSE = 'PCNTrading/common/getCurrentDate';

  // ============== NIKE ==============
  public NIKE_SEARCH          = 'PCNTrading/NikeCBD/searchNikeCBD';
  public NIKE_SEARCH_TOTAL    = 'PCNTrading/NikeCBD/countSearchNikeCBD';
  public NIKE_SEARCH_FAC      = 'PCNTrading/NikeCBD/searchNikeCBDFact';
  public NIKE_SEARCH_FAC_TOTAL= 'PCNTrading/NikeCBD/countSearchNikeCBDFact';
  public NIKE_DELETE          = 'PCNTrading/NikeCBD/deleteNikeCBD';
  public NIKE_COPY_ADD        = 'PCNTrading/NikeCBD/addNikeCBD';
  public NIKE_UPDATE          = 'PCNTrading/NikeCBD/updateNikeCBD';
  public NIKE_EXPORT_TRADING  = 'PCNTrading/NikeCBD/exportNikeCBDFOB';
  public NIKE_EXPORT_FACTORY  = 'PCNTrading/NikeCBD/exportNikeCBDFactory';
  public NIKE_EXPORT_CBDLIST  = 'PCNTrading/NikeCBD/exportNikeCBDList';

}

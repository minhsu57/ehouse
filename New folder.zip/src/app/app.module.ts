import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http, HttpModule } from '@angular/http';
import { appRouting } from './app.routing';
import { Ng2PaginationModule} from 'ng2-pagination';
import { ListService } from './share/list.service';
import { RestService} from './share/rest.service';
import { AppComponent } from './app.component';
import { TradingCompanyComponent } from './trading-company/trading-company.component';
import { NikeComponent } from './nike/nike.component';
import { ConverseComponent } from './converse/converse.component';
import { ConverseFactoryComponent } from './converse-factory/converse-factory.component';
import { NikeFactoryComponent } from './nike-factory/nike-factory.component';

@NgModule({
  declarations: [
    AppComponent,
    TradingCompanyComponent,
    NikeComponent,
    ConverseComponent,
    ConverseFactoryComponent,
    NikeFactoryComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    appRouting,
    Ng2PaginationModule
    
  ],
  providers: [RestService, ListService ],
  bootstrap: [AppComponent]
})
export class AppModule {}


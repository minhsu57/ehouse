import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConverseFactoryComponent } from './converse-factory.component';

describe('ConverseFactoryComponent', () => {
  let component: ConverseFactoryComponent;
  let fixture: ComponentFixture<ConverseFactoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConverseFactoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConverseFactoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

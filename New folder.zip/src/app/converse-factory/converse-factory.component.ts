import { Component, OnInit, AfterViewInit } from '@angular/core';
import { RestService } from '../share/rest.service';
import { ListService } from '../share/list.service';
import $ from 'jquery';

@Component({
  selector: 'app-converse-factory',
  templateUrl: './converse-factory.component.html'
})
export class ConverseFactoryComponent implements OnInit {

  domain    = '';
  factory   = '';
  groupID   = '';
  colorway  = '';
  season    = '';
  startDate = '';
  endDate   = '';
  listMasterData: any[] = [];
  listFactory:    any[] = [];
  listSeason:     any[] = [];
  flagLoader  = true; // disable display
  currentItemID  = -1;

  //permission download file
  flagNullInputMonth   = true;
  flagPermission       = true;

  // pagination
  totalItemSearch: number = 0;
  page: number  = 1;
  itemStart: number = 0;
  itemEnd: number = 10;

  constructor(private service: RestService, private listService: ListService) {
    this.domain = this.listService.DOMAIN_NAME_233;
  }

  ngOnInit() {
    this.getlistFactory();
    this. getlistSeason();
    this.groupID = this.getGID('gid');
  }

  permissionDownload() {
    this.service.get(this.domain + this.listService.PERMISSION_CONVERSE + '?GID=' + this.groupID).subscribe(response => {
      
      if( response[0] != undefined){
          let dataP = response[0].guest.toUpperCase();
          if (dataP == 'FACTORY'){
            this.flagPermission = false;
          }else{
            this.flagPermission = true;
          }
      }else{
        this.flagPermission = true;
      }
      
    });
  }

  downloadFilePriceList(){
    this.exportFile(this.domain + this.listService.EXPRORT_PRICELIST 
      + '?factory='+ this.factory + '&season=' + this.season + '&colorWay=' + this.colorway.toUpperCase()
      + '&date1='+ this.startDate + '&date2=' + this.endDate + '&GID=' + this.groupID, 'export_converse_confirmed_list', '', '.xls');
  }

  downloadFileFactory(factory, season, colorWay){
    this.exportFile(this.domain + this.listService.EXPORT_FACTORY 
      + '?factory=' + factory + '&season=' + season + '&colorWay=' + colorWay, 'export_factory_converse', '', '.xls' );
  }

  exportFile= function(url, filename, data, fileType) {
            fileType = fileType || '.xls';
            filename = (filename) ? (filename  + fileType) : 'Export.csv';
            let stringHeaders = {};
            this.flagLoader   = false;
            let blobType = {};
            if ( fileType === '.xls') {
                blobType = { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
                stringHeaders = {'Content-Type' : 'application/x-www-form-urlencoded'} ;
            }else {
                stringHeaders = {'Content-Type' : 'text/plain'} ;
            }

            this.service.downLoadFile(url, data, stringHeaders ).subscribe(response => {
                this.flagLoader = true;
                var ieEDGE  = navigator.userAgent.match(/Edge/g),
                    ie      = navigator.userAgent.match(/.NET/g), // IE 11+
                    oldIE   = navigator.userAgent.match(/MSIE/g);
                var blob    = new Blob([response._body], blobType); 

                if (ie || oldIE || ieEDGE) {
                    window.navigator.msSaveBlob(blob, filename);
                    this.message  = 'Download file succeed!';
                }else {
                    this.message  = 'Download file succeed!';
                    let link = (<HTMLElement>document.createElement('a'));
                    link.setAttribute('style', 'display: none');
                    let url = window.URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', filename);
                    $('body').append(link);
                    link.click();
                    setTimeout(() => {
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(url);
                    }, 100);
                }
            });
    }

  setCurrentItem(itemID){
    this.currentItemID = itemID;
  }

  searchMasterData(option="search",itemStart = this.itemStart, itemEnd = this.itemEnd) {
      this.flagLoader = false;
      this.service.get(this.domain + this.listService.SEARCH_CONVERSE 
        + '?fact=' +  this.factory + '&colorWay=' + this.colorway.toUpperCase() + '&season=' + this.season 
        + '&date1=' + this.startDate + '&date2=' + this.endDate+ '&start=' + itemStart + '&row=' + itemEnd).subscribe(response => {
            this.flagLoader  = true;
            this.listMasterData.length = 0;
            if (response.length > 0) {
              this.listMasterData = response;
              this.currentItemID = -1;
              if( option == 'search'){
                this.page = 1;
              }
              if( this.startDate != '' && this.endDate != ''){
                this.flagNullInputMonth = false;
              }else{
                this.flagNullInputMonth = true;
              }
            }
      })
      this.countTotalItemSearch();
  }

  countTotalItemSearch() {
    this.service.get(this.domain + this.listService.SEARCH_CONVERSE_TOTAL
        + '?factory=' +  this.factory + '&colorWay=' + this.colorway.toUpperCase() + '&season=' + this.season 
        + '&date1=' + this.startDate + '&date2=' + this.endDate).subscribe(response =>{
          this.totalItemSearch = response;
        })
  }
      
  pageChanged(event) {
    this.page     = event;
    let itemStart = (event * this.itemEnd) - this.itemEnd ;
    this.searchMasterData('pageChange',itemStart);
  }

  checkFormatDataMaster(event, name) {
      let startDate = event.target.value;
      let pattern   = /^([0-9]{4})\/([0-9]{2})\/([0-9]{2})$/;
      if (pattern.test(startDate)) {
          return;
      }else {
           if ( name == 'startDateM') {
            this.startDate = '';
          }else if (name == 'endDateM') {
            this.endDate  = '';
          }
      }
  }

  selectSeason(item,option) {
    if( option == 'search') {
      this.season = item;
    }
  }

  getlistSeason()  {
    this.service.get(this.domain + this.listService.GET_SEASON).subscribe(response => {
      this.listSeason = response;
    });
  }

  selectFactory(item,option) {
    if( option == 'search') {
      this.factory = item;
    }
  }

  getlistFactory()  {
    this.service.get(this.domain + this.listService.GET_FACTORY).subscribe(response =>{
      this.listFactory = response;
    });
  }

  ngAfterViewInit(){
    this.permissionDownload();
  }

  getGID(name) {
      name        = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
      var regexS  = "[\\?&]"+name+"=([^&#]*)";
      var regex   = new RegExp( regexS );
      var results = regex.exec( window.location.href );
      if( results == null ) {
        return '';
      }else {
        return results[1];
      }
   }

}

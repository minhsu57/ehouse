import { Component, OnInit } from '@angular/core';
import { RestService } from '../share/rest.service';
import { ListService } from '../share/list.service';
import $ from 'jquery';

@Component({
  selector: 'app-nike-factory',
  templateUrl: './nike-factory.component.html'
})
export class NikeFactoryComponent implements OnInit {

  domain    = '';
  factory   = '';
  groupID   = '';
  artNo     = '';
  orderMonth= '';
  listMasterData: any[] = [];
  listFactory:    any[] = [];
  flagLoader  = true; // disable display
  currentItemID  = -1;

  //permission download file
  flagNullInputMonth   = true;
  flagPermission       = true;

  // pagination
  totalItemSearch: number = 0;
  page: number  = 1;
  itemStart: number = 0;
  itemEnd: number = 10;

  constructor(private service: RestService, private listService: ListService) {
    this.domain = this.listService.DOMAIN_NAME_233;
  }

  ngOnInit() {
    this.getlistFactory();
    this.groupID = this.getGID('gid');
  }

  permissionDownload() {
    this.service.get(this.domain + this.listService.PERMISSION_CONVERSE + '?GID=' + this.groupID).subscribe(response => {
      if( response[0] != undefined){
          let dataP = response[0].guest.toUpperCase();
          if (dataP == 'FACTORY') {
            this.flagPermission = false;
          }else{
            this.flagPermission = true;
          }
      }else{
        this.flagPermission = true;
      }
    });
  }

  downloadFileFactory(factory, artNo, ordermonth=this.orderMonth){
    this.exportFile(this.domain + this.listService.NIKE_EXPORT_FACTORY 
      + '?factory=' + factory + '&articNo=' + artNo + '&orderMonth=' + ordermonth, 'export_nike_factory', '', '.xls' );
  }

  exportFile= function(url, filename, data, fileType) {
            fileType = fileType || '.xls';
            filename = (filename) ? (filename  + fileType) : 'Export.csv';
            let stringHeaders = {};
            this.flagLoader   = false;
            let blobType = {};
            if ( fileType === '.xls') {
                blobType = { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
                stringHeaders = {'Content-Type' : 'application/x-www-form-urlencoded'} ;
            }else {
                stringHeaders = {'Content-Type' : 'text/plain'} ;
            }

            this.service.downLoadFile(url, data, stringHeaders ).subscribe(response => {
                this.flagLoader = true;
                var ieEDGE  = navigator.userAgent.match(/Edge/g),
                    ie      = navigator.userAgent.match(/.NET/g), // IE 11+
                    oldIE   = navigator.userAgent.match(/MSIE/g);
                var blob    = new Blob([response._body], blobType); 

                if (ie || oldIE || ieEDGE) {
                    window.navigator.msSaveBlob(blob, filename);
                    this.message  = 'Download file succeed!';
                }else {
                    this.message  = 'Download file succeed!';
                    let link = (<HTMLElement>document.createElement('a'));
                    link.setAttribute('style', 'display: none');
                    let url = window.URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', filename);
                    $('body').append(link);
                    link.click();
                    setTimeout(() => {
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(url);
                    }, 100);
                }
            });
    }

  setCurrentItem(itemID){
    this.currentItemID = itemID;
  }

  searchMasterData(option="search",itemStart = this.itemStart, itemEnd = this.itemEnd) {
      this.flagLoader = false;
      let item = {
          "factory"     : this.factory,
          "artNo"       : this.artNo.toUpperCase(),
          "documentDate": this.orderMonth
      };
      this.service.put(this.domain + this.listService.NIKE_SEARCH_FAC + '?start='+ itemStart + '&row=' + itemEnd, item).subscribe(response => {
            this.flagLoader = true;
            this.listMasterData.length = 0;
            if (response.length > 0) {
              this.listMasterData = response;
              this.currentItemID  = -1;
              if( option == 'search'){
                this.page = 1;
              }
              if ( this.orderMonth != '') {
                this.flagNullInputMonth = false;
              }else {
                this.flagNullInputMonth = true;
              }
            }
      });
      this.countTotalItemSearch();
  }

  countTotalItemSearch() {
    let item = {
          "factory": this.factory,
          "artNo": this.artNo.toUpperCase(),
          "documentDate" : this.orderMonth
      };
    this.service.put(this.domain + this.listService.NIKE_SEARCH_FAC_TOTAL, item).subscribe(response =>{
          this.totalItemSearch = response;
    })
  }

  pageChanged(event) {
    this.page     = event;
    let itemStart = (event * this.itemEnd) - this.itemEnd ;
    this.searchMasterData('pageChange',itemStart);
  }

  checkFormatDataMaster(event, name) {
      let startDate = event.target.value;
      let pattern   = /^([0-9]{4})\/([0-9]{2})$/;
      if (pattern.test(startDate)) {
          return;
      }else {
           if ( name == 'orderMonth') {
            this.orderMonth = '';
          }
      }
  }

  selectFactory(item,option) {
    if( option == 'search') {
      this.factory = item;
    }
  }

  getlistFactory()  {
    this.service.get(this.domain + this.listService.GET_FACTORY).subscribe(response =>{
      this.listFactory = response;
    });
  }

  ngAfterViewInit(){
    this.permissionDownload();
  }

  getGID(name) {
      name        = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
      var regexS  = "[\\?&]"+name+"=([^&#]*)";
      var regex   = new RegExp( regexS );
      var results = regex.exec( window.location.href );
      if( results == null ) {
        return '';
      }else {
        return results[1];
      }
   }

}

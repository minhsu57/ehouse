import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NikeFactoryComponent } from './nike-factory.component';

describe('NikeFactoryComponent', () => {
  let component: NikeFactoryComponent;
  let fixture: ComponentFixture<NikeFactoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NikeFactoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NikeFactoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

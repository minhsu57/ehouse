import { Component, OnInit, AfterViewInit  } from '@angular/core';
import $ from 'jquery';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

    ngOnInit() {
        // document.addEventListener('contextmenu', function(e){
        //     e.preventDefault();
        // }, false);
        // $(document).keydown(function(event){
        //     if (event.keyCode === 123) {
        //         return false;
        //       }else if (event.ctrlKey && event.shiftKey && event.keyCode === 73) {        
        //         return false;  // Prevent from ctrl+shift+i
        //     }
        // });
  }
}



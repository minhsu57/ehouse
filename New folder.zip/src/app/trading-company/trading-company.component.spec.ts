import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TraddingCompanyComponent } from './tradding-company.component';

describe('TraddingCompanyComponent', () => {
  let component: TraddingCompanyComponent;
  let fixture: ComponentFixture<TraddingCompanyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TraddingCompanyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TraddingCompanyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});

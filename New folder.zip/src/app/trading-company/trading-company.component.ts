import { Component, OnInit, ElementRef } from '@angular/core';
import { RestService } from '../share/rest.service';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { ListService } from '../share/list.service';
import $ from 'jquery';

@Component({
  selector: 'app-tradding-company',
  templateUrl: './trading-company.component.html',
  styleUrls: ['./trading-company.component.css']
})
export class TradingCompanyComponent implements OnInit {
  domain: string;
  inputFactory = '--Please Select--';
  inputFactoryID = '';
  inputBrand = '--Please Select--';
  inputBrandID = '';
  inputFileFormat = '--Please Select--';
  inputFMID = '';
  listFactory: any[] = [];
  listBrand: any[] = [];
  listFileType: any[] = [];
  groupID  = '';
  fileData: any[]= [];
  message = '';
  flagMessage = false;
  flagFile    = false;
  flagLoader  = true;

  constructor(private services: RestService,
              private elem: ElementRef,
              private http: Http,
              private listService: ListService) {
    this.domain = this.listService.DOMAIN_NAME;
  }

  ngOnInit() {
    this.getFactory();
    this.getBrand();
    this.groupID = this.getGID('gid');
  }

  getGID(name) {
    name      = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS= "[\\?&]"+name+"=([^&#]*)";
    var regex = new RegExp( regexS );
    var results = regex.exec( window.location.href );
    if( results == null )
        return "";
    else
        return results[1];
   }
 
   getFactory() {
    this.services.get(this.domain + this.listService.GET_FACTORY).subscribe(response => {
        this.listFactory = response;
    });
  }

  selectFactory(item, itemID) {
    this.message        = '';
    this.inputFactory   = item;
    this.inputFactoryID = itemID;
  }

  selectBrand(item, itemID) {
    this.message      = '';
    this.inputBrand   = item;
    this.inputBrandID = itemID;
    this.inputFileFormat = '--Please Select--';
    this.services.get(this.domain + this.listService.GET_FILETYPE + itemID).subscribe(response => {
        this.listFileType = response;
    });
  }

  getBrand() {
    this.services.get(this.domain + this.listService.GET_BRAND).subscribe(response => {
        this.listBrand = response;
    });
  }

  selectFileFormat(item, fmID) {
        this.message 		  = '';
        this.inputFileFormat  = item;
        this.inputFMID        = fmID;
   }

   validateFile= function() {
       this.message = '';
       this.flagMessage  = false;
       $('#loadFile').change(() => {
            let files = this.elem.nativeElement.querySelector('#loadFile').files;
            let file = files[0];
            let fileExtendtion = file.name.split('.');
            if (fileExtendtion[1] !== 'csv' && fileExtendtion[1] !== 'xls' ) {
                this.flagMessage  = false;
                this.flagFile	  = false;
                this.message      = 'Please select File *.scv or *.xls !';
                this.fileData 	  = [];
                $('#loadFile').closest('form').trigger('reset');
            }else {
                this.flagFile = true;
                this.fileData = new FormData();
                if (Number(this.inputFMID) === 1) {
                    this.fileData.append('file', file, file.name);
                }else if (Number(this.inputFMID) === 2 || Number(this.inputFMID) === 3) {
                    this.fileData.append('excelFile', file, file.name);
                }
            }
        });
    }

    uploadFiles= function() {
       this.message     = '';
       this.flagLoader = true;
       if (this.inputFileFormat !== '--Please Select--' && this.inputFactory !== '--Please Select--' ) {
            let url = '';
            if ( this.flagFile === true) {
                this.flagLoader = false;
                if (Number(this.inputFMID) === 1) {
                    // tslint:disable-next-line:max-line-length
                    url = this.domain + this.listService.POST_IMPORT_PEGASUS + this.inputBrandID + '&fact=' + this.inputFactoryID + '&fileType=' + this.inputFMID + '&guid=' + this.groupID;
                }else if (Number(this.inputFMID) === 2) {
                    // tslint:disable-next-line:max-line-length
                    url = this.domain + this.listService.POST_IMPORT_MERCURY + this.inputFactoryID + '&fileType=' + this.inputFMID + '&GID=' + this.groupID;
                }else if (Number(this.inputFMID) === 3) {
                    // tslint:disable-next-line:max-line-length
                    url = this.domain + this.listService.POST_IMPORT_EEM + this.inputFactoryID + '&fileType=' + this.inputFMID + '&GID=' + this.groupID;
                }
                this.services.uploadFile(url, this.fileData).subscribe( response => {
                    this.fileData 	= [];
                    this.flagLoader = true;
                    $('#loadFile').closest('form').trigger('reset');
                    let  data = JSON.parse(response._body);
                    if (data.flag) {
                        this.flagMessage  = true;
                        this.flagFile     = false;
                        this.message      = data.message;
                    }else {
                        this.flagMessage  = false;
                        this.message      = data.message;
                    }
                });
            }else {
                this.flagMessage  = false;
                this.message      = 'Please choose file for upload !';
            }
       }else {
           this.flagMessage  = false;
           this.message      = 'Please select data !';
       }
    }

    exportFile= function(url, filename, data, fileType) {
            fileType = fileType || '.xls';
            filename = (filename) ? (filename  + fileType) : 'Export.csv';
            let stringHeaders = {};
            this.flagLoader   = false;
            let blobType = {};
            if ( fileType === '.xls') {
                blobType = { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
                stringHeaders = {'Content-Type' : 'application/x-www-form-urlencoded'} ;
            }else {
                stringHeaders = {'Content-Type' : 'text/plain'} ;
            }

            this.services.downLoadFile(url, data, stringHeaders ).subscribe(response => {
                this.flagLoader = true;
                var ieEDGE  = navigator.userAgent.match(/Edge/g),
                    ie      = navigator.userAgent.match(/.NET/g), // IE 11+
                    oldIE   = navigator.userAgent.match(/MSIE/g);
                var blob    = new Blob([response._body], blobType); 

                if (ie || oldIE || ieEDGE) {
                    window.navigator.msSaveBlob(blob, filename);
                    this.message  = 'Download file succeed!';
                }else {
                    this.message  = 'Download file succeed!';
                    let link = (<HTMLElement>document.createElement('a'));
                    link.setAttribute('style', 'display: none');
                    let url = window.URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', filename);
                    $('body').append(link);
                    link.click();
                    setTimeout(() => {
                        document.body.removeChild(link);
                        window.URL.revokeObjectURL(url);
                    }, 100);
                }
            });
    }
    
    downloadFile = function() {
        this.message = '';
        if (this.inputFileFormat !== '--Please Select--' && Number(this.inputFMID) === 1 && this.inputFactoryID !== '') {
            // tslint:disable-next-line:max-line-length
            this.exportFile( this.domain + this.listService.POST_EXPORT_PEGASUS + this.inputBrandID + '&fact=' + this.inputFactoryID + '&fileType=' + this.inputFMID + '&guid=' + this.groupID, 'pegasusOBS', '', '.csv');
            this.flagMessage  = true;
        }else if ( this.inputFileFormat !== '--Please Select--' && Number(this.inputFMID) === 2 && this.inputFactoryID !== '') {
            // tslint:disable-next-line:max-line-length
            this.exportFile( this.domain + this.listService.POST_EXPORT_MERCURY + this.inputFactoryID + '&fileType=' + this.inputFMID, 'Mercury', '', '.xls');
            this.flagMessage  = true;
        }else if ( this.inputFileFormat !== '--Please Select--' && Number(this.inputFMID) === 3 && this.inputFactoryID !== '') {
            // tslint:disable-next-line:max-line-length
            this.exportFile( this.domain + this.listService.POST_EXPORT_EEM + this.inputFactoryID + '&fileType=' + this.inputFMID, 'EEM', '', '.xls');
            this.flagMessage  = true;
        }else {
            this.message      = 'Please select File to dowload file !';
        }
    }

}
